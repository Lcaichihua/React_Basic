package com.cibertec.pintegrador;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Mesa")
public class Mesa {
	
		@Id
	    @Column
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;
		
		@Column(name = "NombreMesa", nullable = false, length = 70)
		private String NombreMesa;
		
		
		
		@Column
		private boolean estado_consumo;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getNombreMesa() {
			return NombreMesa;
		}

		public void setNombreMesa(String nombreMesa) {
			NombreMesa = nombreMesa;
		}

		public String getAlias_mesa() {
			return Alias_mesa;
		}

		public void setAlias_mesa(String alias_mesa) {
			Alias_mesa = alias_mesa;
		}

		public String getCantidad_pedidos() {
			return cantidad_pedidos;
		}

		public void setCantidad_pedidos(String cantidad_pedidos) {
			this.cantidad_pedidos = cantidad_pedidos;
		}
		
		
}

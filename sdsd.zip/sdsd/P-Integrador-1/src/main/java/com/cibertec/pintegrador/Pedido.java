package com.cibertec.pintegrador;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pedidos")
public class Pedido {
	@Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	@Column(name = "alias_pedido", nullable = false, length = 70)
    private String alias_pedido;
	
	@Column 
    private int id_mesa;
    @Column 
    private Double descuento;
	 @Column 
    private Double monto_total;
	 @Column 
    private boolean estado_pedido;
    @Column
	private Date Hora_pedido;
	
	
	
	
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
	public Double getTotal() {
		return Total;
	}
	public void setTotal(Double total) {
		Total = total;
	}
	public Date getHora_pedido() {
		return Hora_pedido;
	}
	public void setHora_pedido(Date hora_pedido) {
		Hora_pedido = hora_pedido;
	}
	

}

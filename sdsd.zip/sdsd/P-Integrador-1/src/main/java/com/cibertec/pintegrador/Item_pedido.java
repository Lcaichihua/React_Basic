package com.cibertec.pintegrador;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Item_pedidos")
public class Item_pedido {
	@Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	
	@Column(name = "nombre", nullable = false, length = 70)
	private String nombre;
	@Column(name = "descripcion", nullable = false, length = 200)
    private String descripcion;
	@Column(name = "Ingrediente", nullable = false, length = 200) 
	private boolean Ingrediente;
    @Column 
    private Double precio_venta;
	
	@Column 
    private int tiempo_aprox;
	@Column 
	private boolean estado;
	
	 @Column 
    private boolean idcategoria;
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre_adicional() {
		return nombre_adicional;
	}
	public void setNombre_adicional(String nombre_adicional) {
		this.nombre_adicional = nombre_adicional;
	}
	public boolean isIngrediente() {
		return Ingrediente;
	}
	public void setIngrediente(boolean ingrediente) {
		Ingrediente = ingrediente;
	}
	public int getTiempo_aprox() {
		return tiempo_aprox;
	}
	public void setTiempo_aprox(int tiempo_aprox) {
		this.tiempo_aprox = tiempo_aprox;
	}
	public Double getPrecio() {
		return precio;
	}
	public void setPrecio(Double precio) {
		this.precio = precio;
	}
	  
}

package com.cibertec.pintegrador;


import java.util.Date;

import javax.persistence.*;
import javax.validation.constraints.Size;



@Entity
@Table(name = "plato")
public class Plato {
    
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
   
	
	@Column(name = "nombre", nullable = false, length = 70)
	private String nombre;
	@Column(name = "descripcion", nullable = false, length = 200)
    private String descripcion;
	@Column(name = "Ingrediente", nullable = false, length = 200) 
	private boolean Ingrediente;
    @Column 
    private Double precio_venta;
    @Column 
    private Double oferta;
    @Column 
    private int tiempo_aprox;
    @Column 
    private boolean estado;
	
    @Column 
    private boolean idcategoria;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public boolean isIngrediente() {
		return Ingrediente;
	}

	public void setIngrediente(boolean ingrediente) {
		Ingrediente = ingrediente;
	}

	public Double getPrecio() {
		return precio;
	}

	public void setPrecio(Double precio) {
		this.precio = precio;
	}

	public Double getOferta() {
		return oferta;
	}

	public void setOferta(Double oferta) {
		this.oferta = oferta;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public int getTiempo_aprox() {
		return tiempo_aprox;
	}

	public void setTiempo_aprox(int tiempo_aprox) {
		this.tiempo_aprox = tiempo_aprox;
	}

  
    
    
}
